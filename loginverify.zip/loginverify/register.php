<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

session_start();
if (isset($_SESSION['SESSION_EMAIL'])) {
    redirect('welcome.php');
}

require 'vendor/autoload.php';
include 'config.php';

$msg = '';

if (isset($_POST['submit'])) {
    $name = sanitize($conn, $_POST['name']);
    $email = sanitize($conn, $_POST['email']);
    $password = sanitize($conn, $_POST['password']);
    $confirm_password = sanitize($conn, $_POST['confirm-password']);

    if(usernameExists($conn, $email)) {
        $msg = "<div class='alert alert-danger'>{$email} - This email address has already been registered.</div>";
    } elseif($password !== $confirm_password) {
        $msg = "<div class='alert alert-danger'>Password and Confirm Password do not match</div>";
    } else {
        $code = sanitize($conn, rand());
        
        if(registerUser($conn, $name, $email, $password, $code)) {
            sendVerificationMail($email, $code);
            $msg = "<div class='alert alert-info'>We've sent a verification link to your email address.</div>";
        } else {
            $msg = "<div class='alert alert-danger'>Something went wrong.</div>";
        }
    }
}

// Cleans up the user input
function sanitize($conn, $data) {
    return mysqli_real_escape_string($conn, $data);
}

// Check if the users exists
function usernameExists($conn, $email) {
    $result = mysqli_query($conn, "SELECT * FROM users WHERE email='{$email}'");

    return mysqli_num_rows($result) > 0;
}

// Register a new user
function registerUser($conn, $name, $email, $password, $code) {
    $sql = "INSERT INTO users (name, email, password, code) VALUES ('{$name}', '{$email}', '{$password}', '{$code}')";

    return mysqli_query($conn, $sql);
}

function redirect($url) {
    header("Location: $url");
    die();
}

// Send the verification email
function sendVerificationMail($email, $code) {
    // Create an instance; passing true enables exceptions
    $mail = new PHPMailer(true);
    $debug_output = '';

    try {
        // Server settings
        $mail->isSMTP(); 
        $mail->SMTPDebug = SMTP::DEBUG_OFF; // Turn off debug mode for production
        $mail->Host = 'smtp.gmail.com'; 
        $mail->SMTPAuth = true; 
        $mail->Username = ' annikakimi02@gmail.com';
        $mail->Password = 'tyqaqhpvmjkilsmg'; 
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port = 465;

        // Recipients
        $mail->setFrom('from@example.com', 'Kimi Villareal');
        $mail->addAddress($email);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Verification Link';
       
        $mail->Body = 'Here is the verification link: <b><a href="http://localhost/loginverify/?verification=' . $code . '">click me</a></b>';

        ob_start();
        $mail->send();
        $debug_output = ob_get_clean();
        
        echo 'Message has been sent';
    } 
    catch (Exception $e) {
        echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
    } 
    finally {
        echo '<pre>'.htmlspecialchars($debug_output).'</pre>'; // Write debug output to a <pre> element
    }
}
?>

<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Registration Form</title>
    <!-- Meta tag Keywords -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8" />
    <meta name="keywords"
        content="Login Form" />
    <!-- //Meta tag Keywords -->

    <link href="//fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

    <!--/Style-CSS -->
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
    <!--//Style-CSS -->

    <script src="https://kit.fontawesome.com/af562a2a63.js" crossorigin="anonymous"></script>

</head>

<body>

    <!-- form section start -->
    <section class="w3l-mockup-form">
        <div class="container">
            <!-- /form -->
            <div class="workinghny-form-grid">
                <div class="main-mockup">
                    <div class="alert-close">
                        <span class="fa fa-close"></span>
                    </div>
                    <div class="w3l_form align-self">
                        <div class="left_grid_info">
                            <img src="images/image2.svg" alt="">
                        </div>
                    </div>
                    <div class="content-wthree">
                        <h2>Register Now</h2>
                        <p>Make an account to Access our Homepage </p>
                        <?php echo $msg; ?>
                        <form action="" method="post">
                            <input type="text" class="name" name="name" placeholder="Enter Your Name" value="<?php if (isset($_POST['submit'])) { echo $name; } ?>" required>
                            <input type="email" class="email" name="email" placeholder="Enter Your Email" value="<?php if (isset($_POST['submit'])) { echo $email; } ?>" required>
                            <input type="password" class="password" name="password" placeholder="Enter Your Password" required>
                            <input type="password" class="confirm-password" name="confirm-password" placeholder="Enter Your Confirm Password" required>
                            <button name="submit" class="btn" type="submit">Register</button>
                        </form>
                        <div class="social-icons">
                            <p>Have an account! <a href="index.php">Login</a>.</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- //form -->
        </div>
    </section>
    <!-- //form section start -->

    <script src="js/jquery.min.js"></script>
    <script>
        $(document).ready(function (c) {
            $('.alert-close').on('click', function (c) {
                $('.main-mockup').fadeOut('slow', function (c) {
                    $('.main-mockup').remove();
                });
            });
        });
    </script>

</body>

</html>